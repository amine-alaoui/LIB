# Gonum diff [![GoDoc](https://godoc.org/gonum.org/v1/gonum/diff?status.svg)](https://godoc.org/gonum.org/v1/gonum/diff)

Package diff is a package for computing derivatives of functions for the Go language.
