// Copyright ©2017 The Gonum Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package f32 provides float32 vector primitives.
package f32 // import "gonum.org/v1/gonum/internal/asm/f32"
