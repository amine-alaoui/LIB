#!/bin/bash

echo "Ok" > /tmp/postremove-proof
