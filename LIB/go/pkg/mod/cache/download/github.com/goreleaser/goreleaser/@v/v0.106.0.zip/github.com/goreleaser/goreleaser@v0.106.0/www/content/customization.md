---
title: Customization
weight: 30
menu: true
layout: customizations
---

GoReleaser provides multiple customizations via the `.goreleaser.yml` file.

You can generate it by running `goreleaser init` or start from scratch.
The defaults are sensible and fit for most projects.
