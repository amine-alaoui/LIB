#!/bin/bash

echo "Ok" > /tmp/postinstall-proof
