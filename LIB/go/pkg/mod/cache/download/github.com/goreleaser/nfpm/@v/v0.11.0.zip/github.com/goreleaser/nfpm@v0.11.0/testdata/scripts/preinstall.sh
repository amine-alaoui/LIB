#!/bin/bash

echo "Preinstall" > /dev/null
