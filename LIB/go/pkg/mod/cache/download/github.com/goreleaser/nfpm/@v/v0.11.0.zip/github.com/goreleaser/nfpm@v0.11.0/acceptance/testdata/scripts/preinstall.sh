#!/bin/bash

echo "Ok" > /tmp/preinstall-proof
