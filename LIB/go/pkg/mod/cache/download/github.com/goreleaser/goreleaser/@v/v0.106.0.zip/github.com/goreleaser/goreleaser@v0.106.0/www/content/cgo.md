---
title: CGO
weight: 12
menu: true
---

Unfortunately, GoReleaser does not support CGO.

You can see the discussion about this in
[this issue](https://github.com/goreleaser/goreleaser/issues/708).

You can see the comments on the issue referenced for workarounds on it.
