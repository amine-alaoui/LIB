---
title: Project Name
series: customization
hideFromIndex: true
weight: 10
---

The project name is used in the name of the Brew formula, archives, etc.
If none is given, it will be inferred from the name of the Git project.

```yaml
# .goreleaser.yml
project_name: myproject
```
