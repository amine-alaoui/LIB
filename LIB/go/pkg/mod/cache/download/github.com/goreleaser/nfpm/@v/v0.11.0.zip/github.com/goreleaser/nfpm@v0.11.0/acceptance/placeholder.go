package acceptance

// This file only exists to make go test happy.
// No code shall ever live in here.
