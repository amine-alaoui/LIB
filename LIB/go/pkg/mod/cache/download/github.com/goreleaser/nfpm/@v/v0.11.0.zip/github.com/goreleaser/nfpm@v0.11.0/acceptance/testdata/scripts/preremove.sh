#!/bin/bash

echo "Ok" > /tmp/preremove-proof
