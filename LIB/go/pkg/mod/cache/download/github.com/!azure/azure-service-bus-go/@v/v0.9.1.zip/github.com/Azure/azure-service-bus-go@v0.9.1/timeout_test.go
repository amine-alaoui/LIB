// +build !debug

package servicebus

import "time"

const defaultTimeout = 60 * time.Second
