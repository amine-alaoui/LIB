This project follows the [Microsoft Open Source Code of Conduct][CoC]. For more information see the 
[Code of Conduct FAQ][CoCfaq]. Contact [opencode@microsoft.com][CoCmail] with questions and comments.

[guidelines]: http://azure.github.io/guidelines/
[CoC]: https://opensource.microsoft.com/codeofconduct/
[CoCfaq]: https://opensource.microsoft.com/codeofconduct/faq/
[CoCmail]: mailto:opencode@microsoft.com