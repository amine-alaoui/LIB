// Package lorawan provides structures and tools to read and write LoRaWAN 1.0 and 1.1 frames from and to a slice of bytes.
package lorawan
