package band

import "errors"

// errors
var (
	ErrChannelDoesNotExist = errors.New("lorawan/band: channel does not exist")
)
