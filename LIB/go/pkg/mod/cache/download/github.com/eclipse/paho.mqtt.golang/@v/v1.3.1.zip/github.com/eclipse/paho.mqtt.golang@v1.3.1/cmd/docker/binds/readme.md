Binds
=====

Folders within this folder will be bound to folders within the containers; this includes the mosquitto configuration and
persistence files.

Note: While testing some files within these folders may become large and should be deleted when appropriate.