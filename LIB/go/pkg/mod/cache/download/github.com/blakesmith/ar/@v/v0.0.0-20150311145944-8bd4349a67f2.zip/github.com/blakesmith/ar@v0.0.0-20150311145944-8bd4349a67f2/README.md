# Golang ar (archive) file reader

This is a simple library for reading and writing [ar](http://en.wikipedia.org/wiki/Ar_(Unix)) files in common format. It is influenced heavily in style and interface from the golang [tar](http://golang.org/pkg/archive/tar/) package.

## Author

Written by Blake Smith <blakesmith0@gmail.com>

Licensed under the MIT license.