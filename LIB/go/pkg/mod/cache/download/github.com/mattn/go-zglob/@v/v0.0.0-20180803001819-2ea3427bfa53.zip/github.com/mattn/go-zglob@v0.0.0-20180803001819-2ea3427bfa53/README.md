# go-zglob

[![Build Status](https://travis-ci.org/mattn/go-zglob.svg)](https://travis-ci.org/mattn/go-zglob)

zglob

## Usage

```go
matches, err := zglob.Glob(`./foo/b*/**/z*.txt`)
```

## Installation

```
$ go get github.com/mattn/go-zglob
```

## License

MIT

## Author

Yasuhiro Matsumoto (a.k.a mattn)
