[![Build Status](https://travis-ci.org/NickBall/go-aes-key-wrap.svg?branch=master)](https://travis-ci.org/NickBall/go-aes-key-wrap) [![Go Report Card](https://goreportcard.com/badge/github.com/nickball/go-aes-key-wrap)](https://goreportcard.com/report/github.com/nickball/go-aes-key-wrap) [![codecov](https://codecov.io/gh/nickball/go-aes-key-wrap/branch/master/graph/badge.svg)](https://codecov.io/gh/nickball/go-aes-key-wrap)

# go-aes-key-wrap
Golang implementation of the AES Key Wrap algorithm as specified in RFC 3394
