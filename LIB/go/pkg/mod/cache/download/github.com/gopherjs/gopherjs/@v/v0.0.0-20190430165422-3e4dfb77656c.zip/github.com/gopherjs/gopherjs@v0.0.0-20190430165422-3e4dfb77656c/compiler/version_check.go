// +build go1.12
// +build !go1.13

package compiler

const ___GOPHERJS_REQUIRES_GO_VERSION_1_12___ = true

// Version is the GopherJS compiler version string.
const Version = "1.12-2"
